# ReelFren Android WebView

Aplikasi Android sederhana untuk membuka https://reelfren.net/?lang=id.

## Fitur
- WebView dengan JavaScript, DOM Storage, cookie dan media playback.
- Fullscreen video melalui WebChromeClient.
- Riwayat URL yang dibuka disimpan lokal (maksimal 100 entri).
- Tombol Kembali, Beranda, dan Riwayat.

## Build lewat GitHub Actions
1. Buat repository GitHub baru bernama `ReelFren`.
2. Upload seluruh isi folder proyek ini ke root repository (termasuk folder `.github`).
3. Buka tab **Actions** dan izinkan workflow bila diminta.
4. Pilih **Build ReelFren APK** → **Run workflow**.
5. Setelah selesai, buka hasil run dan unduh artifact `ReelFren-debug-apk`.
6. Ekstrak ZIP artifact, lalu instal `app-debug.apk` di Android. Izinkan instalasi dari sumber yang Anda gunakan jika diminta.

## Catatan
APK ini adalah pembungkus situs, bukan pengunduh atau pengubah konten. Riwayat lokal menyimpan URL halaman yang dikunjungi, bukan metadata judul/episode yang mungkin dimuat secara dinamis. Login, pemutaran video, dan fullscreen tetap bergantung pada dukungan situs serta kebijakan penyedia konten.
